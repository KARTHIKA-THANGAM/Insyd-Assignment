# Frontend (Create React App)

## Run
cd frontend
npm install
npm start

- Opens on http://localhost:3000
- Proxy configured to http://localhost:3001 (backend)
