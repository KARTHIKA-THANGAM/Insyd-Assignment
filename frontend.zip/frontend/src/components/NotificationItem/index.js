import './index.css';   // <-- import CSS

export default function NotificationItem({ notif }) {
  return (
    <li className="notification-card">
      <div className="notification-title">
        <strong>{notif.type}</strong> — {notif.message}
      </div>
      <div className="notification-time">
        {new Date(notif.createdAt).toLocaleString()}
      </div>
      <div className={`notification-status ${notif.isRead ? 'read' : 'unread'}`}>
        Status: {notif.isRead ? 'Read' : 'Unread'}
      </div>
    </li>
  );
}
