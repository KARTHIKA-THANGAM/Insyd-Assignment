import API from '../../api';
import './index.css';   // <-- import CSS

export default function TriggerEvent({ userId }) {
  async function send(type) {
    try {
      await API.post('/events', { 
        type, 
        sourceUserId: 'alice', 
        targetUserId: userId, 
        payload: { postId:'p1' } 
      });
      alert('Event sent');
    } catch(err) { 
      console.error(err); 
      alert('Failed'); 
    }
  }

  return (
    <div className="trigger-event">
      <button className="event-btn like-btn" onClick={() => send('like')}>
        Send Like
      </button>
      <button className="event-btn comment-btn" onClick={() => send('comment')}>
        Send Comment
      </button>
    </div>
  );
}
