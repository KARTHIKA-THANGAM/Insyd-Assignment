import { useEffect, useState } from 'react';
import API from '../../api';
import NotificationItem from '../NotificationItem';
import './index.css';   // <-- import CSS

export default function NotificationList({ userId, socket }) {
  const [items, setItems] = useState([]);

  useEffect(() => {
    if (!userId) return;
    fetchNotifications();
  }, [userId]);

  useEffect(() => {
    if (!socket) return;
    socket.on('notification', n => {
      setItems(prev => [n, ...prev]);
    });
    return () => socket.off('notification');
  }, [socket]);

  async function fetchNotifications() {
    try {
      const res = await API.get(`/notifications/${encodeURIComponent(userId)}`);
      setItems(res.data);
    } catch (err) {
      console.error(err);
    }
  }

  return (
    <div className="notification-list">
      <h2 className="notification-heading">Notifications</h2>
      {items.length === 0 ? (
        <div className="no-notifications">No notifications</div>
      ) : (
        <ul className="notification-items">
          {items.map(n => (
            <NotificationItem key={n.id} notif={n} />
          ))}
        </ul>
      )}
    </div>
  );
}
