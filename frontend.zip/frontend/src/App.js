import { useState, useEffect } from 'react';
import io from 'socket.io-client';
import NotificationList from './components/NotificationList';
import TriggerEvent from './components/TriggerEvent';
import "./App.css";

export default function App() {
  const [userId, setUserId] = useState('user1');
  const [socket, setSocket] = useState(null);

  useEffect(() => {
    if(!userId) return;
    const s = io('/', { query: { userId } }); // proxy through CRA to backend
    setSocket(s);
    return () => s.disconnect();
  }, [userId]);

  return (
      <div className="app-container"> 
      <h1>Insyd Notification POC</h1>
      <div style={{ marginBottom: 12 }}>
        <label>User ID: <input value={userId} onChange={e => setUserId(e.target.value)} /></label>
      </div>
      <TriggerEvent userId={userId} />
      <NotificationList userId={userId} socket={socket} />
    </div>
  );
}
