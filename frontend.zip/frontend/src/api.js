import axios from 'axios';

// Use REACT_APP_API_URL if defined (production), otherwise empty string (CRA proxy in dev)
const API = axios.create({
  baseURL: process.env.REACT_APP_API_URL || ''
});

export default API;
