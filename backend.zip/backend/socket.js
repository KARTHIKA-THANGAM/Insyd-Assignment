let io = null;

function init(server) {
  io = require('socket.io')(server, { cors: { origin: '*' } });
  io.on('connection', socket => {
    const userId = socket.handshake.query && socket.handshake.query.userId;
    if(userId) {
      socket.join(`user:${userId}`);
      console.log('Socket connected for user', userId);
    }
    socket.on('disconnect', () => {});
  });
}

function pushToUser(userId, payload) {
  if(!io) return;
  io.to(`user:${userId}`).emit('notification', payload);
}

module.exports = { init, pushToUser };
