# Backend (Express + SQLite + Socket.IO)

## Run
cd backend
npm install
npm start

- Server runs on http://localhost:3001 by default.
- APIs:
  POST /events
  GET /notifications/:userId
  POST /notifications/:id/read

The server uses notifications.db (preloaded) in the same folder.
