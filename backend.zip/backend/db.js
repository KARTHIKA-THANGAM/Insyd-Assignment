const path = require('path');
const sqlite3 = require('sqlite3').verbose();
const DB_PATH = path.join(__dirname, 'notifications.db');

function open() {
  return new sqlite3.Database(DB_PATH);
}

module.exports = { open, DB_PATH };
