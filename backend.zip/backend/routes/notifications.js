const express = require('express');
const router = express.Router();
const dbModule = require('../db');

router.get('/:userId', (req, res) => {
  const userId = req.params.userId;
  const db = dbModule.open();
  db.all('SELECT id, userId, type, message, isRead, createdAt FROM notifications WHERE userId = ? ORDER BY createdAt DESC LIMIT 100', [userId], (err, rows) => {
    db.close();
    if(err) return res.status(500).json({ error: err.message });
    res.json(rows);
  });
});

router.post('/:id/read', (req, res) => {
  const id = req.params.id;
  const db = dbModule.open();
  db.run('UPDATE notifications SET isRead = 1 WHERE id = ?', [id], function(err) {
    db.close();
    if(err) return res.status(500).json({ error: err.message });
    if(this.changes === 0) return res.status(404).json({ error: 'not found' });
    res.json({ status: 'ok' });
  });
});

module.exports = router;
