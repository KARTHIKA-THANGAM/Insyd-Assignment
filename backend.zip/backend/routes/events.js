const express = require('express');
const router = express.Router();
const { enqueue } = require('../queue');

router.post('/', async (req, res) => {
  const event = req.body;
  if(!event || !event.type || !event.sourceUserId) return res.status(400).json({ error: 'invalid event' });
  enqueue(event);
  res.status(202).json({ status: 'queued' });
});

module.exports = router;
