const express = require('express');
const bodyParser = require('body-parser');
const cors = require('cors');
const http = require('http');
const eventsRoute = require('./routes/events');
const notificationsRoute = require('./routes/notifications');
const socketModule = require('./socket');

const app = express();
app.use(cors());
app.use(bodyParser.json());

app.use('/events', eventsRoute);
app.use('/notifications', notificationsRoute);

const PORT = process.env.PORT || 3001;
const server = http.createServer(app);
socketModule.init(server);

server.listen(PORT, () => {
  console.log('Backend running on http://localhost:' + PORT);
});
