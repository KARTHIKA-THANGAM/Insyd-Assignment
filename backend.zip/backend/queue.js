// simple in-process queue for POC
const dbModule = require('./db');
const socket = require('./socket');

async function processEvent(event) {
  const { type, sourceUserId, targetUserId, payload } = event;
  if(!targetUserId) return;
  const message = `${sourceUserId} ${type}ed your post${payload && payload.postId ? ' ' + payload.postId : ''}`;
  const db = dbModule.open();
  return new Promise((resolve, reject) => {
    const stmt = db.prepare('INSERT INTO notifications (userId, type, message, isRead, createdAt) VALUES (?, ?, ?, 0, datetime("now"))');
    stmt.run(targetUserId, type, message, function(err) {
      stmt.finalize();
      db.close();
      if(err) return reject(err);
      const created = { id: this.lastID, userId: targetUserId, type, message, isRead:0, createdAt: new Date().toISOString() };
      // push via socket
      socket.pushToUser(targetUserId, created);
      resolve(created);
    });
  });
}

const queue = [];
let processing = false;

function enqueue(event) {
  queue.push(event);
  if(!processing) processQueue();
}

async function processQueue() {
  processing = true;
  while(queue.length) {
    const ev = queue.shift();
    try {
      await processEvent(ev);
    } catch(err) {
      console.error('Error processing event', err);
    }
  }
  processing = false;
}

module.exports = {enqueue};
